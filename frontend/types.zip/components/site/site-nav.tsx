"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, X, Search } from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { journalMeta, navLinks } from "@/lib/site-data";
import TrinixLogo from "@/components/site/trinix-logo";

export default function SiteNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      <div className="relative overflow-hidden bg-slate-950 text-white/80 text-xs">
        <div
          className="absolute inset-0 bg-gradient-to-r from-saffron-500/20 via-transparent to-saffron-400/15"
          aria-hidden
        />
        <div className="relative mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-2">
          <span className="tracking-wide">
            {journalMeta.issnPrint} | {journalMeta.issnOnline}
          </span>
          <span className="hidden md:inline">{journalMeta.location}</span>
        </div>
      </div>
      <div className="border-b border-saffron-100/80 bg-white/85 backdrop-blur">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <TrinixLogo
            title={journalMeta.shortTitle}
            subtitle="Advanced Engineering and Sciences"
          />

          <nav className="hidden lg:flex items-center gap-6 text-sm text-slate-600">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "transition hover:text-saffron-600",
                  pathname === link.href && "text-saffron-600 font-semibold"
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            <Link
              href="/search"
              aria-label="Search"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-saffron-100 bg-white text-saffron-700 shadow-sm transition hover:border-saffron-200 hover:text-saffron-800"
            >
              <Search className="h-4 w-4" />
              <span className="sr-only">Search</span>
            </Link>
            <Button
              asChild
              className="rounded-full bg-saffron-500 text-slate-900 shadow-sm hover:bg-saffron-400"
            >
              <Link href="/manuscript-login">Submit Manuscript</Link>
            </Button>
          </div>

          <button
            type="button"
            className="inline-flex items-center justify-center rounded-full border border-saffron-100 bg-white p-2 text-saffron-700 shadow-sm lg:hidden"
            aria-label="Toggle menu"
            onClick={() => setOpen((prev) => !prev)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {open && (
          <div className="border-t border-saffron-100/80 bg-white/95 px-6 py-4 lg:hidden">
            <div className="flex flex-col gap-3 text-sm text-slate-700">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "rounded-lg px-3 py-2 transition hover:bg-saffron-50",
                    pathname === link.href && "bg-saffron-50 font-semibold text-saffron-700"
                  )}
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/search"
                aria-label="Search"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-saffron-100 bg-white text-saffron-700 shadow-sm transition hover:border-saffron-200 hover:text-saffron-800"
                onClick={() => setOpen(false)}
              >
                <Search className="h-4 w-4" />
                <span className="sr-only">Search</span>
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
