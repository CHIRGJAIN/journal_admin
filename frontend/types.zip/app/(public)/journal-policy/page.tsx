import PageHeader from "@/components/site/page-header";
import QuickLinksSidebar from "@/components/site/quick-links-sidebar";

const policySections = [
  {
    title: "Open access",
    body:
      "Trinix Journal operates a hybrid open access model. Authors may choose open access licensing or subscription-based publishing. APC waivers are available for invited manuscripts until Dec 2025.",
    tone: "border-sky-100 bg-gradient-to-br from-white via-sky-50 to-white",
  },
  {
    title: "Licensing",
    body:
      "Authors retain copyright and may select Creative Commons licenses (CC BY 4.0 or CC BY-NC 4.0) for open access articles. All submissions must include a signed publishing agreement.",
    tone: "border-amber-100 bg-gradient-to-br from-white via-amber-50 to-white",
  },
  {
    title: "Archiving and indexing",
    body:
      "Digital preservation is provided through long-term archival partners. Metadata is prepared for indexing agencies, DOI registration, and institutional repositories.",
    tone: "border-emerald-100 bg-gradient-to-br from-white via-emerald-50 to-white",
  },
  {
    title: "Author rights",
    body:
      "Authors may share accepted manuscripts on personal or institutional repositories with proper citation and embargo compliance.",
    tone: "border-indigo-100 bg-gradient-to-br from-white via-indigo-50 to-white",
  },
];

export default function JournalPolicyPage() {
  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <PageHeader
        eyebrow="Journal policy"
        title="Transparent publishing policies and open access options"
        description="Our journal policies follow COPE recommendations and prioritize ethical, accessible research dissemination."
      />

      <div className="mt-10 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          {policySections.map((section) => (
            <section
              key={section.title}
              className={`relative overflow-hidden rounded-3xl border p-8 shadow-sm ${section.tone}`}
            >
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-slate-900 via-slate-500 to-slate-900 opacity-70" />
              <h2 className="font-display text-2xl text-slate-900">{section.title}</h2>
              <p className="mt-3 text-sm text-slate-600">{section.body}</p>
            </section>
          ))}
        </div>

        <QuickLinksSidebar />
      </div>
    </div>
  );
}
