import PageHeader from "@/components/site/page-header";
import QuickLinksSidebar from "@/components/site/quick-links-sidebar";

const ethicsSections = [
  {
    title: "Originality and plagiarism",
    body:
      "Manuscripts are screened for similarity using plagiarism detection tools. Significant overlap, duplicate submissions, or fabricated content lead to rejection and editorial review.",
    tone: "border-sky-100 bg-gradient-to-br from-white via-sky-50 to-white",
  },
  {
    title: "Authorship and conflicts",
    body:
      "All contributors must meet authorship criteria. Conflicts of interest are disclosed by authors, reviewers, and editors to maintain impartial review.",
    tone: "border-amber-100 bg-gradient-to-br from-white via-amber-50 to-white",
  },
  {
    title: "Ethical oversight",
    body:
      "Research involving human participants or animals must include approval from the appropriate ethics committees and consent documentation.",
    tone: "border-emerald-100 bg-gradient-to-br from-white via-emerald-50 to-white",
  },
  {
    title: "Corrections and retractions",
    body:
      "We publish corrections, clarifications, or retractions when necessary to preserve the integrity of the scholarly record.",
    tone: "border-indigo-100 bg-gradient-to-br from-white via-indigo-50 to-white",
  },
];

export default function PublicationEthicsPage() {
  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <PageHeader
        eyebrow="Publication ethics"
        title="Ethics-first scholarly publishing"
        description="We follow COPE guidelines to ensure integrity, transparency, and accountability in all published work."
      />

      <div className="mt-10 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          {ethicsSections.map((section) => (
            <section
              key={section.title}
              className={`relative overflow-hidden rounded-3xl border p-8 shadow-sm ${section.tone}`}
            >
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-slate-900 via-slate-500 to-slate-900 opacity-70" />
              <h2 className="font-display text-2xl text-slate-900">{section.title}</h2>
              <p className="mt-3 text-sm text-slate-600">{section.body}</p>
            </section>
          ))}
        </div>

        <QuickLinksSidebar />
      </div>
    </div>
  );
}
