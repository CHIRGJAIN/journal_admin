import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Calendar, Clock, Tag } from "lucide-react";

import QuickLinksSidebar from "@/components/site/quick-links-sidebar";
import { blogPosts } from "@/lib/site-data";

function formatDate(date: string) {
  return new Date(date).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

export default async function BlogDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    notFound();
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <Link
        href="/blog"
        className="inline-flex items-center gap-2 text-sm font-semibold text-slate-700 transition hover:text-slate-900"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to blog
      </Link>

      <div className="mt-6 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <article className="space-y-6 rounded-3xl border border-slate-200/80 bg-white p-8 shadow-sm">
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
            <span className="rounded-full bg-slate-900 px-3 py-1 text-white">{post.category}</span>
            <span className="inline-flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {formatDate(post.date)}
            </span>
            <span className="inline-flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {post.readTime}
            </span>
          </div>

          <div className="space-y-3">
            <h1 className="font-display text-3xl text-slate-900 md:text-4xl">{post.title}</h1>
            <p className="text-sm uppercase tracking-[0.25em] text-slate-500">
              {post.author} · {post.role}
            </p>
          </div>

          <div className="flex flex-wrap gap-2 text-xs text-slate-600">
            {post.tags.map((tag) => (
              <span
                key={`${post.slug}-${tag}`}
                className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-3 py-1"
              >
                <Tag className="h-3 w-3" />
                {tag}
              </span>
            ))}
          </div>

          <div className="space-y-4 text-base leading-7 text-slate-700">
            {post.content.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>

          {post.highlight && (
            <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">
              Key takeaway: {post.highlight}
            </div>
          )}

          <div className="rounded-2xl bg-gradient-to-r from-sky-50 to-emerald-50 px-4 py-3 text-sm text-slate-700">
            Want to contribute a note like this?{" "}
            <Link href="/contact" className="font-semibold text-slate-900 underline">
              Reach the editorial office
            </Link>
            .
          </div>
        </article>

        <QuickLinksSidebar />
      </div>
    </div>
  );
}
