'use client';

import Link from "next/link";
import { ArrowRight, Calendar, Clock, Tag } from "lucide-react";
import { useState, useEffect } from "react";

import PageHeader from "@/components/site/page-header";
import QuickLinksSidebar from "@/components/site/quick-links-sidebar";
import { cn } from "@/lib/utils";
import { blogPosts } from "@/lib/site-data";
import { blogService } from "@/services";
import { ApiError } from "@/lib/apiClient";

function formatDate(date: string) {
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

const categoryColors: Record<string, string> = {
  "AI & Infrastructure": "from-sky-100 to-sky-50 border-sky-100",
  "Editorial Practice": "from-amber-100 to-amber-50 border-amber-100",
  "Energy Systems": "from-emerald-100 to-emerald-50 border-emerald-100",
  "Peer Review": "from-indigo-100 to-indigo-50 border-indigo-100",
  Materials: "from-rose-100 to-rose-50 border-rose-100",
  "For Authors": "from-cyan-100 to-cyan-50 border-cyan-100",
};

export default function BlogPage() {
  const [posts, setPosts] = useState(blogPosts);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await blogService.getAllPosts(1, 50);
        // If API returns data, use it; otherwise fall back to static data
        if (response.posts && response.posts.length > 0) {
          setPosts(response.posts as any);
        }
      } catch (err) {
        // Fallback to static data on error
        console.warn('Failed to fetch blog posts from API, using static data');
        if (err instanceof ApiError) {
          console.error('API Error:', err.message);
        }
        setPosts(blogPosts);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  const topics = Array.from(new Set(posts.map((post: any) => post.category)));
  const spotlight = posts.slice(0, 2);

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-6xl px-6 py-10">
        <PageHeader
          eyebrow="Insights"
          title="Journal news, editor notes, and author resources"
          description="Stay updated on policy changes, editorial guidance, and technology trends shaping advanced engineering research."
        />
        <div className="mt-10 text-center text-slate-500">Loading blog posts...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto w-full max-w-6xl px-6 py-10">
        <PageHeader
          eyebrow="Insights"
          title="Journal news, editor notes, and author resources"
          description="Stay updated on policy changes, editorial guidance, and technology trends shaping advanced engineering research."
        />
        <div className="mt-10 text-center text-red-500">Error loading blog posts: {error}</div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <PageHeader
        eyebrow="Insights"
        title="Journal news, editor notes, and author resources"
        description="Stay updated on policy changes, editorial guidance, and technology trends shaping advanced engineering research."
      />

      <div className="mt-10 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          {posts.map((post: any, index: number) => (
            <article
              key={post.slug}
              className={cn(
                "group relative overflow-hidden rounded-3xl border bg-gradient-to-br from-white via-slate-50 to-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-slate-300 hover:shadow-xl",
                categoryColors[post.category] ?? "border-slate-200/80"
              )}
            >
              <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-slate-900 via-slate-500 to-slate-900 opacity-70" />
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                <span className="rounded-full bg-slate-900/90 px-3 py-1 text-white shadow-sm">
                  {post.category}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-white/60 px-3 py-1 shadow-sm">
                  <Calendar className="h-4 w-4" />
                  {formatDate(post.date || post.publishedAt || new Date().toISOString())}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-white/60 px-3 py-1 shadow-sm">
                  <Clock className="h-4 w-4" />
                  {post.readTime || '5 min'}
                </span>
                {post.highlight && (
                  <span className="rounded-full bg-emerald-50 px-3 py-1 text-emerald-700 border border-emerald-100">
                    {post.highlight}
                  </span>
                )}
              </div>
              <h3 className="mt-4 font-display text-2xl text-slate-900 group-hover:text-slate-950">
                {post.title}
              </h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">{post.summary || post.excerpt}</p>
              <p className="mt-4 text-xs uppercase tracking-[0.25em] text-slate-500">
                {post.author} · {post.role || 'Editor'}
              </p>
              <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-500">
                {(post.tags || []).map((tag: string) => (
                  <span
                    key={`${post.slug}-${tag}`}
                    className="inline-flex items-center gap-1 rounded-full border border-slate-200/80 bg-white px-3 py-1 shadow-sm"
                  >
                    <Tag className="h-3 w-3" />
                    {tag}
                  </span>
                ))}
              </div>
              <Link
                href={`/blog/${post.slug}`}
                className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-slate-900"
              >
                Read the full note <ArrowRight className="h-4 w-4" />
              </Link>
              {index < 2 && spotlight[index]?.highlight && (
                <div className="mt-5 rounded-2xl border border-slate-100 bg-gradient-to-r from-sky-50 to-emerald-50 px-4 py-3 text-xs text-slate-600 shadow-inner">
                  Spotlight: {spotlight[index].highlight}
                </div>
              )}
            </article>
          ))}
        </div>

        <div className="space-y-6">
          <div className="rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm">
            <h3 className="font-semibold text-slate-900">Topics we cover</h3>
            <p className="mt-2 text-sm text-slate-600">
              Curated for authors, reviewers, and readers following our focus areas.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {topics.map((topic) => (
                <span
                  key={topic}
                  className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-700"
                >
                  {topic}
                </span>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200/80 bg-slate-900 p-6 text-white shadow-sm">
            <h3 className="font-display text-xl">Submit a story</h3>
            <p className="mt-2 text-sm text-white/80">
              Share lab notes, reproducibility guides, or policy perspectives. Our editors will
              work with you on clarity and compliance.
            </p>
            <Link
              href="/contact"
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-slate-900 transition hover:bg-white/90"
            >
              Pitch to the editors <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <QuickLinksSidebar />
        </div>
      </div>
    </div>
  );
}
