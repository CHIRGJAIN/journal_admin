'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { authService } from '@/services';
import { ApiError } from '@/lib/apiClient';
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import Link from 'next/link';

export default function LoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    const resolveDashboardRoute = (roles?: string) => {
        const normalized = roles
            ?.split(',')
            .map((role) => role.trim().toUpperCase())
            .filter(Boolean) ?? [];

        if (normalized.includes('EDITOR')) return '/editor';
        if (normalized.includes('REVIEWER')) return '/reviewer';
        return '/author';
    };

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setLoading(true);

        try {
            const response = await authService.loginUser({ email, password });

            // Store token and user info
            localStorage.setItem('token', response.token);
            localStorage.setItem('user', JSON.stringify(response.user));

<<<<<<< HEAD
            // Redirect to dashboard
            router.push('/author');
        } catch (err) {
            const message = err instanceof ApiError ? err.message : 'Login failed';
            setError(message);
        } finally {
            setLoading(false);
=======
            router.push(resolveDashboardRoute(data.user?.roles));
        } catch (error) {
            alert('Login failed');
>>>>>>> cf82d7b05ce03a1407826f3b0343d7776f58282d
        }
    };

    return (
        <div className="flex h-screen items-center justify-center bg-slate-50">
            <Card className="w-[350px]">
                <CardHeader>
                    <CardTitle>Login</CardTitle>
                    <CardDescription>Enter your credentials to access the journal.</CardDescription>
                </CardHeader>
                <CardContent>
                    {error && (
                        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded">
                            {error}
                        </div>
                    )}
                    <form onSubmit={handleLogin}>
                        <div className="grid w-full items-center gap-4">
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="email">Email</Label>
                                <Input
                                    id="email"
                                    placeholder="Email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    disabled={loading}
                                    required
                                />
                            </div>
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="password">Password</Label>
                                <Input
                                    id="password"
                                    type="password"
                                    placeholder="Password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    disabled={loading}
                                    required
                                />
                            </div>
                        </div>
                    </form>
                </CardContent>
                <CardFooter className="flex justify-between flex-col gap-2">
                    <Button
                        className="w-full"
                        onClick={handleLogin}
                        disabled={loading}
                    >
                        {loading ? 'Signing in...' : 'Login'}
                    </Button>
                    <p className="text-xs text-center">
                        {"Don't"} have an account? <Link href="/register" className="underline">Register</Link>
                    </p>
                </CardFooter>
            </Card>
        </div>
    );
}
