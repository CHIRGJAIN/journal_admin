/**
 * Manuscript Service
 * Handles manuscript submission and management
 */

import { apiClient } from '@/lib/apiClient';

export interface Manuscript {
  id: string;
  title: string;
  abstract: string;
  authors: string[];
  status: 'draft' | 'submitted' | 'under-review' | 'accepted' | 'rejected';
  submittedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SubmitManuscriptRequest {
  title: string;
  abstract: string;
  authors: string[];
  content: string;
  keywords?: string[];
}

class ManuscriptService {
  /**
   * Get all manuscripts for current user
   */
  async getMyManuscripts(): Promise<Manuscript[]> {
    return apiClient.get<Manuscript[]>('/manuscripts');
  }

  /**
   * Get manuscript by ID
   */
  async getManuscript(id: string): Promise<Manuscript> {
    return apiClient.get<Manuscript>(`/manuscripts/${id}`);
  }

  /**
   * Submit new manuscript
   */
  async submitManuscript(payload: SubmitManuscriptRequest): Promise<Manuscript> {
    return apiClient.post<Manuscript>('/manuscripts', payload);
  }

  /**
   * Update manuscript draft
   */
  async updateManuscript(id: string, payload: Partial<SubmitManuscriptRequest>): Promise<Manuscript> {
    return apiClient.put<Manuscript>(`/manuscripts/${id}`, payload);
  }

  /**
   * Delete manuscript
   */
  async deleteManuscript(id: string): Promise<{ message: string }> {
    return apiClient.delete<{ message: string }>(`/manuscripts/${id}`);
  }

  /**
   * Withdraw manuscript submission
   */
  async withdrawSubmission(id: string): Promise<{ message: string }> {
    return apiClient.post<{ message: string }>(`/manuscripts/${id}/withdraw`, {});
  }
}

export const manuscriptService = new ManuscriptService();
