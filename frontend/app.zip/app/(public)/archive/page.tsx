"use client";

import { useMemo, useState, useEffect } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { ArrowRight, Download } from "lucide-react";

import { Button } from "@/components/ui/button";
import PageHeader from "@/components/site/page-header";
import QuickLinksSidebar from "@/components/site/quick-links-sidebar";
import { archiveIssues } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { issueService } from "@/services";
import type { Issue } from "@/services/issue.service";
import { ApiError } from "@/lib/apiClient";
import { formatPublicationDate } from "@/lib/date-utils";

const issuePalette = [
  "border-sky-100 bg-gradient-to-br from-white via-sky-50 to-white",
  "border-emerald-100 bg-gradient-to-br from-white via-emerald-50 to-white",
  "border-amber-100 bg-gradient-to-br from-white via-amber-50 to-white",
  "border-indigo-100 bg-gradient-to-br from-white via-indigo-50 to-white",
  "border-rose-100 bg-gradient-to-br from-white via-rose-50 to-white",
  "border-cyan-100 bg-gradient-to-br from-white via-cyan-50 to-white",
];

export default function ArchivePage() {
  const searchParams = useSearchParams();
  const selectedIssue = searchParams.get("issue");
  const [selectedYear, setSelectedYear] = useState("All");
  const [selectedVolume, setSelectedVolume] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [totalIssues, setTotalIssues] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const ITEMS_PER_PAGE = 6;

  useEffect(() => {
    const fetchIssues = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const params: unknown = {
          limit: ITEMS_PER_PAGE,
          page: currentPage,
          status: 'PUBLISHED'
        };
        
        if (selectedYear !== "All") {
          params.year = parseInt(selectedYear);
        }
        
        if (selectedVolume !== "All") {
          params.volume = parseInt(selectedVolume);
        }
        
        const response = await issueService.getAllIssues(params);
        const list = response.data ?? response.issues ?? [];

        setIssues(list as Issue[]);
        setTotalIssues(response.total ?? list.length);
        setTotalPages(response.totalPages || Math.ceil((response.total ?? list.length) / ITEMS_PER_PAGE));
      } catch (err) {
        console.warn('Failed to fetch issues from API, using static data');
        if (err instanceof ApiError) {
          console.error('API Error:', err.message);
        }
        setIssues([]);
        setTotalIssues(archiveIssues.length);
      } finally {
        setLoading(false);
      }
    };

    fetchIssues();
  }, [currentPage, selectedYear, selectedVolume]);

  const years = useMemo(() => {
    // Generate years from current year back to 2020
    const currentYear = new Date().getFullYear();
    const yearList = [];
    for (let year = currentYear; year >= 2020; year--) {
      yearList.push(year);
    }
    return yearList;
  }, []);

  const volumes = useMemo(() => {
    // Generate volumes 1 to 10
    return Array.from({ length: 10 }, (_, i) => i + 1);
  }, []);



  if (loading) {
    return (
      <div className="mx-auto w-full max-w-6xl px-6 py-10">
        <PageHeader
          eyebrow="Archive"
          title="Past Issues"
          description="Browse all published volumes and issues of Trinix Journal."
        />
        <div className="mt-10 text-center text-slate-500">Loading issues...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto w-full max-w-6xl px-6 py-10">
        <PageHeader
          eyebrow="Archive"
          title="Past Issues"
          description="Browse all published volumes and issues of Trinix Journal."
        />
        <div className="mt-10 text-center text-red-500">Error loading issues: {error}</div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <PageHeader
        eyebrow="Journal archive"
        title="Volumes, issues, and full archives"
        description="Browse issue-level collections, explore highlights, and access published articles across the journal timeline."
      />

      <div className="mt-10 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          <div className="flex flex-wrap gap-4 rounded-2xl border border-slate-200/70 bg-gradient-to-r from-white via-slate-50 to-white p-4 shadow-sm">
            <label className="text-xs text-slate-500">
              Year
              <select
                value={selectedYear}
                onChange={(event) => {
                  setSelectedYear(event.target.value);
                  setCurrentPage(1);
                }}
                className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700"
              >
                <option value="All">All</option>
                {years.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-xs text-slate-500">
              Volume
              <select
                value={selectedVolume}
                onChange={(event) => {
                  setSelectedVolume(event.target.value);
                  setCurrentPage(1);
                }}
                className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700"
              >
                <option value="All">All</option>
                {volumes.map((volume) => (
                  <option key={volume} value={volume}>
                    Vol {volume}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="grid gap-6">
            {issues && issues.map((issue) => (
              <div
                key={issue.slug}
                className={cn(
                  "group rounded-3xl border p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg",
                  issuePalette[(issue.volume + (issue.issueNumber ?? 0)) % issuePalette.length],
                  selectedIssue === issue.slug && "ring-2 ring-slate-900/10"
                )}
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-xs uppercase tracking-[0.3em] text-slate-500">
                      Volume {issue.volume} - Issue {issue.issueNumber}
                    </p>
                    <h2 className="mt-2 font-display text-2xl text-slate-900">
                      {issue.publicationDate ? formatPublicationDate(issue.publicationDate) : `${issue.month} ${issue.year}`}
                    </h2>
                  </div>
                  <div className="rounded-full border border-slate-200/80 bg-white/70 px-4 py-2 text-xs text-slate-600 shadow-sm">
                    Pages {issue.totalPages ?? 0} | {(issue.manuscripts ?? []).length} articles
                  </div>
                </div>
                <ul className="mt-4 flex flex-wrap gap-2 text-xs text-slate-500">
                  
                   {issue.keywords && issue.keywords.length > 0 && 
                    issue.keywords.flatMap((keyword) => 
                      keyword.split(',').map((item) => item.trim())
                    ).map((item, idx) => (
                      <li
                      key={idx}
                      className="rounded-full border border-slate-200/80 bg-white/80 px-3 py-1 shadow-sm"
                    >
                      {item}
                    </li>
                    ))
                  }
                </ul>
                <div className="mt-5 flex flex-wrap gap-3">
                  <Button asChild className="rounded-full bg-slate-900 text-white hover:bg-slate-800">
                    <Link href={`/search?issue=${issue.slug}`}>
                      View Issue <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  {/* <Button variant="outline" className="rounded-full border-slate-300" disabled>
                    <Download className="mr-2 h-4 w-4" />
                    PDF Coming Soon
                  </Button> */}
                </div>
              </div>
            ))}
          </div>

          {currentPage < totalPages && (
            <div className="flex justify-center gap-3">
              <Button
                variant="outline"
                className="rounded-full border-slate-300"
                onClick={() => setCurrentPage((page) => page + 1)}
              >
                Load more issues
              </Button>
              <span className="flex items-center text-sm text-slate-500">
                Page {currentPage} of {totalPages}
              </span>
            </div>
          )}

          {issues.length === 0 && !loading && (
            <div className="rounded-2xl border border-dashed border-slate-200 p-6 text-sm text-slate-500">
              No issues found for the selected filters.
            </div>
          )}
        </div>

        <QuickLinksSidebar />
      </div>
    </div>
  );
}
